public class Assignment3_main
{
public static void main(String[] args)
   {
      Assignment3_methods comp = new Assignment3_methods();
      comp.go();
   }
}